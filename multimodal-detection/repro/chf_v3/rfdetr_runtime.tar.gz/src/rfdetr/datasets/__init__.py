# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
# Copied and modified from LW-DETR (https://github.com/Atten4Vis/LW-DETR)
# Copyright (c) 2024 Baidu. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
# Modified from Conditional DETR (https://github.com/Atten4Vis/ConditionalDETR)
# Copyright (c) 2021 Microsoft. All Rights Reserved.
# ------------------------------------------------------------------------
# Copied from DETR (https://github.com/facebookresearch/detr)
# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
# ------------------------------------------------------------------------

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Any

import torchvision
from torch.utils.data import Dataset, Subset

from rfdetr.config import DatasetFile
from rfdetr.datasets._keypoint_schema import infer_coco_keypoint_schema as infer_coco_keypoint_schema
from rfdetr.datasets._keypoint_schema import infer_yolo_keypoint_schema as infer_yolo_keypoint_schema
from rfdetr.datasets.coco import build_coco, build_roboflow_from_coco
from rfdetr.datasets.o365 import build_o365
from rfdetr.datasets.webdataset.load import build_webdataset
from rfdetr.datasets.yolo import (
    YoloDetection,
    build_roboflow_from_yolo,
    find_yolo_data_file,
    find_yolo_train_images,
)


def get_coco_api_from_dataset(dataset: Dataset[Any]) -> Any | None:
    for _ in range(10):
        if isinstance(dataset, Subset):
            dataset = dataset.dataset
    if isinstance(dataset, torchvision.datasets.CocoDetection):
        return dataset.coco
    if isinstance(dataset, YoloDetection):
        return dataset.coco
    return None


def detect_roboflow_format(dataset_dir: Path) -> str:
    """Detect if a Roboflow dataset is in COCO or YOLO format.

    Args:
        dataset_dir: Path to the Roboflow dataset root directory

    Returns:
        'coco' if COCO format detected, 'yolo' if YOLO format detected

    Raises:
        ValueError: If neither format is detected
    """
    # Check for COCO format: look for _annotations.coco.json in train folder
    coco_annotation = dataset_dir / "train" / "_annotations.coco.json"
    if coco_annotation.exists():
        return "coco"

    if find_yolo_train_images(dataset_dir) is not None:
        return "yolo"

    yolo_data_file = find_yolo_data_file(dataset_dir)
    if yolo_data_file is not None:
        # Naming the config that was found keeps the message from reading as "no data.yaml
        # here" when one is present but declares nothing usable.
        raise ValueError(
            f"Could not detect dataset format in {dataset_dir}. Found the YOLO data file {yolo_data_file}, "
            f"but no training image directory resolved from it: neither its 'train' path nor "
            f"{dataset_dir / 'train' / 'images'} is a directory inside the dataset. "
            f"Enable debug logging to see each declaration that was rejected."
        )

    raise ValueError(
        f"Could not detect dataset format in {dataset_dir}. "
        f"Expected either COCO format (train/_annotations.coco.json) "
        f"or YOLO format (data.yaml or data.yml + training images resolved from YAML or train/images/)"
    )


def build_roboflow(image_set: str, args: Any, resolution: int) -> Dataset[Any]:
    """Build a Roboflow dataset, auto-detecting COCO or YOLO format.

    This function detects the dataset format and delegates to the appropriate builder function.
    """
    root = Path(args.dataset_dir)
    assert root.exists(), f"provided Roboflow path {root} does not exist"

    dataset_format = detect_roboflow_format(root)

    if dataset_format == "coco":
        return build_roboflow_from_coco(image_set, args, resolution)
    return build_roboflow_from_yolo(image_set, args, resolution)


#: Dataset builder per ``TrainConfig.dataset_file`` value. Adding a layout means one entry here plus its name in
#: :data:`rfdetr.config.DatasetFile`; ``tests/datasets/test_builder_options.py`` keeps the two in sync.
_DATASET_BUILDERS: dict[DatasetFile, Callable[[str, Any, int], Dataset[Any]]] = {
    "coco": build_coco,
    "o365": build_o365,
    "roboflow": build_roboflow,
    "yolo": build_roboflow_from_yolo,
    "webdataset": build_webdataset,
}


def build_dataset(image_set: str, args: Any, resolution: int) -> Dataset[Any]:
    """Build the dataset for *image_set* using the builder registered for ``args.dataset_file``.

    Args:
        image_set: Split to build, e.g. ``"train"``, ``"val"`` or ``"test"``.
        args: Merged model/train config namespace; ``args.dataset_file`` selects the builder.
        resolution: Target square resolution in pixels.

    Returns:
        The dataset produced by the registered builder.

    Raises:
        ValueError: If ``args.dataset_file`` names no registered builder.
    """
    builder = _DATASET_BUILDERS.get(args.dataset_file)
    if builder is None:
        raise ValueError(f"dataset {args.dataset_file} not supported; expected one of {tuple(_DATASET_BUILDERS)}")
    return builder(image_set, args, resolution)
